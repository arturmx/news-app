import Middle from './components/Middle'
import './reset.scss'
import './common.scss'

function App() {
  return (
    <div>

      <Middle />

    </div>
  );
}

export default App;
