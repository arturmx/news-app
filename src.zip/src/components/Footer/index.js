import './footer.scss';
const Footer = function() {
    return (
        <div className="footer">
            <div className="container">

            </div>
        </div>
    )
}

export default Footer